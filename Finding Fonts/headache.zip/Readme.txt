Headache font is completely free for personal and commercial use.

https://www.behance.net/casotabogdan