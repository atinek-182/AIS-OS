Grith is a bold and condensed display font crafted as a modified version of Bebas Neue. With it's blacked-out style and softened sharp corners, Grith strikes a balance between strength and subtle sophistication; a powerful yet refined look. Designed to embody resilience and determination, this font is perfect for impactful headlines, logos, and designs that demand attention while exuding a sense of bold character.

Follow:
https://www.behance.net/yosinasution