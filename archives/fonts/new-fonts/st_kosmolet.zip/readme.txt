By downloading and/or installing Shimanov Types® fonts you agree to the following user license terms:

Free license
(desktop + webfont + others)

This font can be used for personal and commercial works. You can use this font at a home or business location on an unlimited worstations.

Allowed:

you can do any kind of design work with this font, including logo/trademarks design.
the font may be used in editable embedding pdfs and other similar documents.
the font may be used in e-publications, apps, games, broadcasting, enterprise, educational, etc.

Not allowed:

you may not sell this font.
you may not modify, adapt, translate, reverse engineer, decompile, disassemble or create derivative works based on this font.

Like and follow:
https://www.behance.net/shimanov

Buy a coffee:
https://shimanov.pro/st-kosmolet