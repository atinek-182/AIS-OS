Font by Irhasalfahad

Licensed with a Creative Commons attribution license.

If you add to the font, please send me a copy! If you've made fun stuff with the font that you would like to show me, please send me that as well. I like that.

Have fun,
Irhas
irhasalfahad@gmail.com

If this font suddenly makes you feel like spending huge amounts of money, please do so by going to Paypal and transferring your fortune to irhasalfahad@gmail.com
And if this font suddenly makes feel like spending small or fairly large amounts of money, you can do that via Paypal as well.
