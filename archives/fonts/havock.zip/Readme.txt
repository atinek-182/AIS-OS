---------------------------------------

This Font Is Free For Personal and Commercial Use.
Selling or Re-Constructing This Font is Forbidden

Do Not Sell This Font without Author Prior Approval.

---------------------------------------


Check Out Our Another More COMMERCIAL FONTS:
https://www.grontype.com


Any DONATION will be appreciated
https://www.paypal.me/jarnawisaja


For CUSTOM LICENSE, Please contact us :
jarnawisaja@gmail.com
---------------------------------------


THANK YOU FOR YOUR SUPPORT!