Hello everyone

Today, we are sharing you a new typography school project.
So we created the typeface "FIRST" to meet this demand.

This typeface is also FREE to use.

Buy a coffee:
https://nothight.gumroad.com/l/FIRSTtypeface

Follow us on our different social media:
https://www.instagram.com/not__hight/
https://x.com/HIGHT_____
https://www.behance.net/arthurgrange1

We really appreciate your attention, one last ask, can you mention us under your works?
Have a good continuation :)